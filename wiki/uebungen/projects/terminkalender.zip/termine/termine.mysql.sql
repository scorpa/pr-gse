CREATE TABLE kalender (
	k_id INT PRIMARY KEY AUTO_INCREMENT,
	k_name VARCHAR(64)
);


CREATE TABLE termine (
	t_id INT PRIMARY KEY AUTO_INCREMENT,
	fk_k_id INT,
	t_von TIMESTAMP,
	t_bis TIMESTAMP,
	t_text VARCHAR(128)

);

ALTER TABLE TERMINE ADD FOREIGN KEY(fk_k_id) REFERENCES kalender(k_id);
