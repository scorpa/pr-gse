package fachlogik;

import java.util.Date;

public class Termin 
{
	private int id;
	private Date von;
	private Date bis;
	private String text;
	
	/**
	 * Ein neuer Termin hat die id=0 ==> muss erst in Datenbank gespeichert werden (INSERT)
	 * Andernfalls: UPDATE
	 */
	public Termin()
	{
		id = 0;
	}
	
	public int getId()
	{
		return id;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	public Date getVon()
	{
		return von;
	}
	
	public void setVon(Date von)
	{
		this.von = von;
	}
	
	public Date getBis()
	{
		return bis;
	}
	
	public void setBis(Date bis)
	{
		this.bis = bis;
	}
	
	public String getText()
	{
		return text;
	}
	
	public void setText(String text)
	{
		this.text = text;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Termin other = (Termin) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "Termin [id=" + id + ", von=" + von + ", bis=" + bis + ", text="
				+ text + "]";
	}
	
	


}
