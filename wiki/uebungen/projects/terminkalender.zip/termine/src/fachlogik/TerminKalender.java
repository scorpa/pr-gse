package fachlogik;

import java.util.ArrayList;
import java.util.List;

public class TerminKalender 
{

	private int id;
	private String name;
	private List<Termin> termine;
	
	/**
	 * Ein neuer Terminkalender hat id=0 ==> muss erst in der Datenbank gespeichert werden (INSERT)
	 * Andernfalls UPDATE
	 */
	public TerminKalender()
	{
		id = 0;
		termine = new ArrayList<>();
	}

	/**
	 * F�gt einen neuen Termin in den Terminkalender ein.
	 * Falls der Termin mit einem anderen �berlappt, wird eine TerminException ausgel�st.
	 * @param t
	 * @throws TerminException falls der Termin mit einem anderen �berlappt.
	 */
	public void neu(Termin t) throws TerminException
	{
		// TODO neuer Termin wird eingef�gt. Er darf sich mit keinem vorhandenen Termin �berschneiden.
	}

	public int getId()
	{
		return id;
	}


	public void setId(int id)
	{
		this.id = id;
	}


	public String getName()
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}


	/**
	 * Beim ersten Aufruf der Methode m�ssen die Termine aus der Datenbank geladen werden.
	 * @return
	 */
	public List<Termin> getTermine()
	{
		// TODO Termine m�ssen aus der Datenbank geladen werden, falls sie nicht vorhanden sind.
		// (lazy initialization)
		return termine;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TerminKalender other = (TerminKalender) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		return "TerminKalender [id=" + id + ", name=" + name + "]";
	}
	
	
	
	
	
	

}
