package fachlogik;

import java.util.List;

public interface DataAccessObject
{
	/**
	 * Liefert eine Liste aller vorhandenen Terminkalender. 
	 * Die einzelnen Termine werden noch nicht geladen. 
	 * (Das geschieht erst beim ersten Aufruf der Methode getTermine(); lazy initialization)
	 * 
	 * @return liste aller Terminkalender
	 * @throws TerminException falls ein Datenbankzugriffsfehler auftritt
	 */
	public List<TerminKalender> alleKalender() throws TerminException;
	
		
	/**
	 * Findet einen Terminkalender anhand der �bergebenen id.
	 * Die einzelnen Termine werden noch nicht geladen. 
	 * (Das geschieht erst beim ersten Aufruf der Methode getTermine(); lazy initialization)
	 * 
	 * @param id ID der Terminkalenders
	 * @return Referenz auf den gefundenen Terminkalender
	 * @throws TerminException falls der Terminkalender nicht gefunden wird oder
	 * 			ein Datenbankzugriffsfehler auftritt
	 */
	public TerminKalender finde(int id) throws TerminException;
	
	
	/**
	 * Findet alle Terminkalender, deren Namen mit dem �bergebenen String beginnen
	 * (ignoriert Gro�- und Kleinschreibung).
	 * Die einzelnen Termine werden noch nicht geladen. 
	 * (Das geschieht erst beim ersten Aufruf der Methode getTermine(); lazy initialization)
	 * 
	 * @param namensBeginn Beginn des Namens
	 * @return Liste der gefundenen Terminkalender
	 * @throws TerminException falls ein Datenbankzugriffsfehler auftritt
	 */
	public List<TerminKalender> finden(String namensBeginn) throws TerminException;
	
	
	/**
	 * Der �bergebene Terminkalender wird mitsamt allen Terminen gepeichert.
	 * (Das Speichern der Termine kann zu einem INSERT, UPDATE oder DELETE f�hren;
	 * muss innerhalb der Methode entschieden werden.)
	 * 
	 * @param k Termin, der zu speichern ist
	 * @throws TerminException falls ein Datenbankzugriffsfehler auftritt.
	 */
	public void speichern(TerminKalender k) throws TerminException;
	
	
	
	/**
	 * L�scht einen Terminkalender mitsamt seinen Terminen
	 * @param k zu l�schender Terminkalender
	 * @throws TerminException falls ein Datenbankzugriffsfehler auftritt
	 */
	public void loeschen(TerminKalender k) throws TerminException;
	

}
